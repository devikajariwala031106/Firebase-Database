import AddProduct from "./components/AddProduct";
import ProductList from "./components/ProductList";
import "./styles/app.css";

function App() {
  return (
    <div className="app-container">
      <h1>Inventory Tracking System</h1>
      <AddProduct />
      <ProductList />
    </div>
  );
}

export default App;