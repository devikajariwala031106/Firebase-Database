import { useState } from "react";
import { useDispatch } from "react-redux";
import { addProduct } from "../redux/productSlice";

function AddProduct() {
    const dispatch = useDispatch();

    const [product, setProduct] = useState({
        name: "",
        category: "",
        price: "",
        stock: ""
    });

    const handleChange = (e) => {
        setProduct({
            ...product,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        dispatch(addProduct(product));

        setProduct({
            name: "",
            category: "",
            price: "",
            stock: ""
        });
    };

    return (
        <form className="product-form" onSubmit={handleSubmit}>
            <h2>Add Product</h2>

            <input name="name" placeholder="Product Name" value={product.name} onChange={handleChange} />
            <input name="category" placeholder="Category" value={product.category} onChange={handleChange} />
            <input name="price" type="number" placeholder="Price" value={product.price} onChange={handleChange} />
            <input name="stock" type="number" placeholder="Stock" value={product.stock} onChange={handleChange} />

            <button type="submit">Add Product</button>
        </form>
    );
}

export default AddProduct;