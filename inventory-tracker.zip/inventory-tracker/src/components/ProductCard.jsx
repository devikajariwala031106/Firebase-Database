import { useDispatch } from "react-redux";
import { deleteProduct } from "../redux/productSlice";

function ProductCard({ id, product }) {
    const dispatch = useDispatch();

    const lowStock = Number(product.stock) < 5;

    return (
        <div className={`product-card ${lowStock ? "low-stock" : ""}`}>
            <h3>{product.name}</h3>
            <p>Category: {product.category}</p>
            <p>Price: ₹{product.price}</p>
            <p>Stock: {product.stock}</p>

            {lowStock && <span className="alert-badge">Low Stock</span>}

            <button onClick={() => dispatch(deleteProduct(id))}>
                Delete
            </button>
        </div>
    );
}

export default ProductCard;