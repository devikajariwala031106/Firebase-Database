import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../redux/productSlice";
import ProductCard from "./ProductCard";

function ProductList() {
    const dispatch = useDispatch();
    const products = useSelector((state) => state.products.items);

    useEffect(() => {
        dispatch(fetchProducts());
    }, [dispatch]);

    return (
        <div className="product-list">
            <h2>Inventory Products</h2>

            <div className="product-grid">
                {Object.entries(products).map(([id, product]) => (
                    <ProductCard key={id} id={id} product={product} />
                ))}
            </div>
        </div>
    );
}

export default ProductList;