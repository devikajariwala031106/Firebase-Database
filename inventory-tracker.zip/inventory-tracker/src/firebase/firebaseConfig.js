import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyDndPCeR1Wp-DkUoO22nJZUyCGNvur1I0w",
    authDomain: "inventory-app-442d2.firebaseapp.com",
    databaseURL: "https://inventory-app-442d2-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "inventory-app-442d2",
    storageBucket: "inventory-app-442d2.firebasestorage.app",
    messagingSenderId: "783276514271",
    appId: "1:783276514271:web:b4e05940c41e345641c26a",
    measurementId: "G-VGX1M1717Z"
};

const app = initializeApp(firebaseConfig);

export const database = getDatabase(app);