import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { database } from "../firebase/firebaseConfig";
import { ref, push, set, get, remove } from "firebase/database";

export const fetchProducts = createAsyncThunk(
    "products/fetchProducts",
    async () => {
        const snapshot = await get(ref(database, "products"));
        return snapshot.exists() ? snapshot.val() : {};
    }
);

export const addProduct = createAsyncThunk(
    "products/addProduct",
    async (product) => {
        const newRef = push(ref(database, "products"));
        await set(newRef, product);
        return { id: newRef.key, ...product };
    }
);

export const deleteProduct = createAsyncThunk(
    "products/deleteProduct",
    async (id) => {
        await remove(ref(database, `products/${id}`));
        return id;
    }
);

const productSlice = createSlice({
    name: "products",
    initialState: {
        items: {}
    },
    reducers: {},
    extraReducers: (builder) => {
        builder.addCase(fetchProducts.fulfilled, (state, action) => {
            state.items = action.payload;
        });

        builder.addCase(addProduct.fulfilled, (state, action) => {
            state.items[action.payload.id] = action.payload;
        });

        builder.addCase(deleteProduct.fulfilled, (state, action) => {
            delete state.items[action.payload];
        });
    }
});

export default productSlice.reducer;